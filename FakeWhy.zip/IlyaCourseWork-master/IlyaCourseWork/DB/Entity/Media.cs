﻿namespace IlyaCourseWork.DB.Entity
{
    public class Media
    {
        public int Id { get; set; }
        public string PageName { get; set; }
        public string HTMLCode { get; set; }
    }
}
