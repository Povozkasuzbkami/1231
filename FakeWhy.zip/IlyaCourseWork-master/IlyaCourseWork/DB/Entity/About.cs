﻿namespace IlyaCourseWork.DB.Entity
{
    public class About
    {
        public int Id { get; set; }
        public string PageName { get; set; }
        public string HTMLCode { get; set; }
    }
}
