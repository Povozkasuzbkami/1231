﻿namespace IlyaCourseWork.DB.Entity
{
    public class Products
    {
        public int Id { get; set; }
        public string PageName { get; set; }
        public string HTMLCode { get; set; }
    }
}
